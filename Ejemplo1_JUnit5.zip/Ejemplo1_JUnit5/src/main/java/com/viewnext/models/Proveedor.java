package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

public class Proveedor {
	
	private String nombre;
	private List<Producto> productos;
	
	public Proveedor() {
		productos = new ArrayList<Producto>();
	}
	
	public void addProducto(Producto producto) {
		productos.add(producto);
		producto.setProveedor(this);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	@Override
	public String toString() {
		return "Proveedor [nombre=" + nombre + ", productos=" + productos + "]";
	}
	
}

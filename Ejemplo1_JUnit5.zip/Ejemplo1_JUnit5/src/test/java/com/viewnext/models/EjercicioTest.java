package com.viewnext.models;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

public class EjercicioTest {

	static Proveedor proveedor;
	
	@BeforeAll
	static void inicioClasePrueba() {
		proveedor = new Proveedor();
		proveedor.setNombre("Siemens");
	}
	
	@AfterAll
	static void finClasePrueba() {		
		Assertions.assertAll(
				() -> Assertions.assertNotNull(proveedor.getProductos()),
				() -> Assertions.assertEquals(4, proveedor.getProductos().size()),
				() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
						.filter(prod -> prod.getDescripcion().equals("Impresora"))
						.findAny()
						.get().getDescripcion())
		);
	}
	
	// EJERCICIO
	// 1.- Crear un productos.csv con 4 productos    id,descripcion,precio
	// 2.- Testear la relaccion entre producto proveedor
	//     utilizando los test parametrizados
	@ParameterizedTest
	@CsvFileSource(resources = "/productos.csv")
	void testRelaccionProductoProveedor2(int id, String descripcion, double precio) {
		Producto producto2 = new Producto();
		producto2.setID(id);
		producto2.setDescripcion(descripcion);
		producto2.setPrecio(precio);
		
		// El Proveedor es estatico para que solo exista uno.
		//Proveedor proveedor = new Proveedor();
		//proveedor.setNombre("Siemens");
		
		proveedor.addProducto(producto2);	
		
		// Las aserciones se hacen al final de la prueba, en el metodo @AfterAll
	}
}

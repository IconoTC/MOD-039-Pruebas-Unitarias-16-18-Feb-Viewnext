package com.viewnext.models;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestReporter;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.DisabledIfSystemProperties;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.AfterParameterizedClassInvocation;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	@BeforeAll
	// Debe ser estatico
	static void inicioClasePrueba() {
		// Este metodo se ejecuta una sola vez al inicio de la clase
		// Iniciamos un log donde guardar el resultado de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}
	
	@AfterAll
	// Debe ser estatico
	static void finClasePrueba() {
		// Este metodo se ejecuta una sola vez al final de la clase
		// Cerrar el log
		System.out.println("Terminamos de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		producto = null;
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Probando la clase Producto")
	//@Disabled
	class ProductoPruebas{
		
		@Test
		@DisplayName("Probando la descripcion de producto")
		//@Disabled
		@Tag("producto")
		public void testDescripcion() {
			// 1.- Arrange u Organizar
			//Producto producto = new Producto(1, "Impresora", 129.95);
			
			// 2.- Act o Actuar
			String descripcionReal = producto.getDescripcion();
			String descripcionEsperada = "Impresora";
			
			// 3.- Assert o Afirmar
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
		
		@Test
		@DisplayName("Probando el precio del producto")
		@Tag("producto")
		public void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			double precio = producto.getPrecio();
			Assertions.assertTrue(precio > 0);
			//Assertions.assertFalse(precio <= 0);
		}
		
		@Test
		@DisplayName("Probando la igualdad de objetos")
		public void testIgualdadObjetos() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}
		
		@Test
		@DisplayName("Probando si lanza excepcion con precio negativo")
		public void testPrecioNegativoException() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			
			// Comprobar si lanza la excepcion al cambiar a precio negativo
			Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-234);
			});
			
			// Comprobar el mensaje de la excepcion
			Exception ex = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-234);
			});
			String msgReal = ex.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);
		}
	}
	
	@Nested
	@DisplayName("Probando los test de la clase Proveedor")
	class ProveedorPruebas{
		
		@Test
		@Tags({@Tag("producto"), @Tag("proveedor")} )
		//@Tag("producto")
		//@Tag("proveedor")
		void testRelaccionProductoProveedor() {
			Producto producto2 = new Producto(2, "Scanner", 237.50);
			
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("Siemens");
			
			proveedor.addProducto(producto);
			proveedor.addProducto(producto2);
			
			/*
			// Comprobamos que la lista de productos no es nula
			Assertions.assertNotNull(proveedor.getProductos());
			
			// Comprobamos que la lista de productos tiene una longitud 2
			Assertions.assertEquals(2, proveedor.getProductos().size());
			
			// Comprobar que el proveedor tiene un producto Impresora (streams de Java 8)
			Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
					.filter(prod -> prod.getDescripcion().equals("Impresora"))
					.findAny()
					.get().getDescripcion()  );
			*/
			// Forzar para que se evaluen todas las aserciones haya fallo en las primeras o no
			Assertions.assertAll(
					() -> Assertions.assertNotNull(proveedor.getProductos()),
					() -> Assertions.assertEquals(2, proveedor.getProductos().size()),
					() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> prod.getDescripcion().equals("Impresora"))
							.findAny()
							.get().getDescripcion())
			);
		}
	}
	
	@Nested
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("La prueba se ejecuta si el SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("La prueba se ejecuta si el SO es Mac o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Esta prueba se deshabilita si el SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("La prueba se ejecuta si la version de Java es 8");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_21)
		void testSoloJava21() {
			System.out.println("La prueba se ejecuta si la version de Java es 21");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_8)
		void testNoJava8() {
			System.out.println("La prueba se deshabilita si la version de Java es 8");
		}
	}
	
	@Nested
	@DisplayName("Pruebas de System Properties")
	class SystemProperties{
		
		@Test
		void verSystemProperties() {
			Properties properties = System.getProperties();
			//properties.forEach( (k,v) -> System.out.println(k + ": " + v) );
		}
		
		// java.version: 1.8.0_111
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
		void testJavaVersion() {
			System.out.println("Tu version de java es 1.8.0_111");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de java es 1.8.0_111");
		}
		
		// Tambien se pueden deshabilitar pruebas segun propiedades del sistema
		//@DisabledIfSystemProperty
	}
	
	@Nested
	@DisplayName("Pruebas para Variables de Entorno")
	class VariablesEntorno{
		
		@Test
		void verVariablesEntorno() {
			Map<String, String> variables = System.getenv();
			//variables.forEach((k,v) -> System.out.println(k + ": " + v));
		}
		
		// USER: anaisabelvegascaceres
		@Test
		@EnabledIfEnvironmentVariable(named = "USER", matches = "anaisabelvegascaceres")
		void testUser() {
			System.out.println("Tu usuario es anaisabelvegascaceres");
		}
		
		@Test
		@DisabledIfEnvironmentVariable(named = "USER", matches = "pepito")
		void testNoUser() {
			System.out.println("Tu usuario es pepito");
		}
	}
	
	
	@Test
	@DisplayName("Probando el precio del producto con assumptions")
	void testAssumptions() {
		// Habilitar o deshabilitar un test o parte del test en funcion de una condicion 
		// de forma programatica
		// user.language: es
		boolean lenguaje = "es".equals(System.getProperty("user.language"));
		
		// Omitir la prueba entera
		//Assumptions.assumeTrue(lenguaje);   la prueba continua porque la condicion es true
		//Assumptions.assumeFalse(lenguaje); //la prueba se para porque no cumple la condicion
		
		// Si solo queremos omitir parte del codigo, no la prueba completa
		// utilizamos assumingThat
		// Si el lenguaje es "es" realiza la prueba, si no lo es la omite
		Assumptions.assumingThat(lenguaje, () -> {
			Assertions.assertTrue(producto.getPrecio() <= 0);
			Assertions.assertEquals(129.95, producto.getPrecio());
		});
		
		System.out.println("La prueba continua ..........");
	}
	
	@RepeatedTest(value = 3, name = "Repeticion nº {currentRepetition} del total {totalRepetitions}")
	void testRepetido(RepetitionInfo infoRep) {
		System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
		double numero = Math.random();
		System.out.println(numero);
		Assertions.assertNotNull(numero);
		Assertions.assertTrue(numero >= 0);
	}
	
	// Test parametrizados: se trata de pasar varios datos como parametros y
	// asi poder realizar la prueba con cada uno de ellos
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@ValueSource(doubles = {57, 0, -12})  // array de parametros
	void testPrecios(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {0} con valor {1}")
	@CsvSource({"0,57", "1,0", "2,-12"})   // csv de parametros
	void testPreciosCsvSource(String idx, double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@CsvFileSource(resources = "/datos.csv")   // archivo csv de parametros
	void testPreciosCsvFileSource(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name = "parametro {index} con valor {0}")
	@MethodSource("queryPrecios")
	void testPreciosMethodSource(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	// Este metodo debe ser estatico
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a una BBDD para traer la lista de precios
		return Arrays.asList(57.0, 0.0, -12.0);
	}
	
	@Test
	@Tag("producto")
	@DisplayName("Probando la descripcion del producto con TestInfo y TestReporter")
	void testDescripcionInfo(TestInfo info, TestReporter reporter) {
		
		System.out.println(info.getDisplayName() + " ****************");
		System.out.println(info.getTestMethod() + " ****************");
		System.out.println(info.getTags() + " ****************");
		
		reporter.publishEntry("Mensaje", "Esto es una prueba");
		
		String descripcionReal = producto.getDescripcion();
		String descripcionEsperada = "Impresora";
		Assertions.assertEquals(descripcionEsperada, descripcionReal);
	}
	
	@Test
	@Timeout(value = 1000, unit = TimeUnit.MILLISECONDS)
	void testTiempo() throws InterruptedException {
		
		// Probamos si el test tarda mas de 1 segundo dara la prueba como fallida,
		// Si tarda menos de 1 segundo dara la prueba como buena
		
		Thread.sleep(975);
		
		System.out.println("Probando el timeout");
		
	}
	
	// Hay otra forma de hacerlo
	@Test
	void testTiempo2() throws InterruptedException {
		// Probamos si el test tarda mas de 1 segundo dara la prueba como fallida,
		// Si tarda menos de 1 segundo dara la prueba como buena
		
		Assertions.assertTimeout(Duration.ofSeconds(1), () -> {
			Thread.sleep(500);
			System.out.println("Probando el timeout");
		});
	}
	
}













package com.viewnext.business;

import java.util.List;
import java.util.Optional;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.ActorDAO;
import com.viewnext.persistence.PeliculaDAO;

public class PeliculaBSImpl implements PeliculaBS{
	
	private PeliculaDAO peliculaDAO;
	private ActorDAO actorDAO;
	
	public PeliculaBSImpl(PeliculaDAO peliculaDAO, ActorDAO actorDAO) {
		super();
		this.peliculaDAO = peliculaDAO;
		this.actorDAO = actorDAO;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOpt = peliculaDAO.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (peliculaOpt.isPresent()) {
			pelicula = peliculaOpt.get();
		}
		return pelicula;
	}

	@Override
	public Pelicula findPeliculaByNombreConActores(String nombre) {
		Pelicula pelicula = findPeliculaByNombre(nombre);
		
		if (pelicula != null) {
			List<String> reparto = actorDAO.findActoresByPelicula(pelicula.getId());
			pelicula.setActores(reparto);
		}
		return pelicula;
	}

	@Override
	public Pelicula crearNueva(Pelicula pelicula) {
		if (!pelicula.getActores().isEmpty()) {
			actorDAO.crearListaActores(pelicula.getActores());
		}
		return peliculaDAO.crear(pelicula);
	}

}








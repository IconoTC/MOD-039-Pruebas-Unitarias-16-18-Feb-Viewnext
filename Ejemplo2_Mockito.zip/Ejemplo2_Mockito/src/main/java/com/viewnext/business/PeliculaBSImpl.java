package com.viewnext.business;

import java.util.Optional;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.PeliculaDAO;

public class PeliculaBSImpl implements PeliculaBS{
	
	private PeliculaDAO peliculaDAO;
	
	public PeliculaBSImpl(PeliculaDAO peliculaDAO) {
		super();
		this.peliculaDAO = peliculaDAO;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOpt = peliculaDAO.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (peliculaOpt.isPresent()) {
			pelicula = peliculaOpt.get();
		}
		return pelicula;
	}

	@Override
	public Pelicula findPeliculaByNombreConActores(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.viewnext.business;

import com.viewnext.models.Pelicula;

public interface PeliculaBS {
	
	Pelicula findPeliculaByNombre(String nombre);
	
	Pelicula findPeliculaByNombreConActores(String nombre);
	
	Pelicula crearNueva(Pelicula pelicula);

}

package com.viewnext.persistence;

import java.util.List;

import com.viewnext.models.Pelicula;

public interface PeliculaDAO {
	
	List<Pelicula> findAll();

}

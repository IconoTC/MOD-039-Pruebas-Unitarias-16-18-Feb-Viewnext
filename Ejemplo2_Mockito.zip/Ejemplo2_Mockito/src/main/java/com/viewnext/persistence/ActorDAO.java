package com.viewnext.persistence;

import java.util.List;

public interface ActorDAO {
	
	List<String> findActoresByPelicula(Long id);
	
	void crearListaActores(List<String> actores);

}

package com.viewnext.persistence;

import java.util.ArrayList;
import java.util.List;

public class ActorDAOImpl implements ActorDAO{

	@Override
	public List<String> findActoresByPelicula(Long id) {
		System.out.println("Metodo real del DAO");
		List<String> actores = new ArrayList<String>();
		
		switch (id.toString()) {
			case "1":
				actores.add("Eduard Fernandez");
				actores.add("Salva Reina");
				break;
	
			case "2":
				actores.add("Carolina Yuste");
				actores.add("Luis Tosar");
				break;
	
			case "3":
				actores.add("Juliane Moore");
				actores.add("Tilda Swinton");
				break;
	
			default:
				break;
		}
		
		return actores;
	}

	@Override
	public void crearListaActores(List<String> actores) {
		System.out.println("Creando la lista de actores ....");	
	}

}

package com.viewnext.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.PeliculaDAO;
import com.viewnext.utils.Datos;

public class PeliculaBSImplTest {
	
	PeliculaDAO peliculaDAO;
	PeliculaBS peliculaBS;
	
	@BeforeEach
	void inicioPrueba() {
		// No se puede crear un mock de cualquier metodo, solo public o default
		// nunca de un metodo privado o estatico o tampoco final
		peliculaDAO = Mockito.mock(PeliculaDAO.class);
		peliculaBS = new PeliculaBSImpl(peliculaDAO);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		//PeliculaDAO peliculaDAO = Mockito.mock(PeliculaDAO.class);
		//PeliculaBS peliculaBS = new PeliculaBSImpl(peliculaDAO);
		
		// Cuando pedimos buscar todas las peliculas retorne Datos.PELICULAS
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}

}

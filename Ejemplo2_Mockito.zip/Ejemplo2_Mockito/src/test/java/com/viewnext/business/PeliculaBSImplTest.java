package com.viewnext.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.ActorDAO;
import com.viewnext.persistence.ActorDAOImpl;
import com.viewnext.persistence.PeliculaDAO;
import com.viewnext.persistence.PeliculaDAOImpl;
import com.viewnext.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculaBSImplTest {
	
	// Para poder llamar al metodo real necesitamos tener el mock de la clase
	// y no de la interface
	@Mock
	PeliculaDAOImpl peliculaDAO;
	
	@Mock
	ActorDAOImpl actorDAO;
	
	@InjectMocks
	PeliculaBSImpl peliculaBS;  // Debe ser la clase y no la interface
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	@BeforeEach
	void inicioPrueba() {
		// No se puede crear un mock de cualquier metodo, solo public o default
		// nunca de un metodo privado o estatico o tampoco final
		// peliculaDAO = Mockito.mock(PeliculaDAO.class);   // Objeto ficticio
		// actorDAO = Mockito.mock(ActorDAO.class);  // Objeto ficticio
		// peliculaBS = new PeliculaBSImpl(peliculaDAO, actorDAO);    // Objeto real
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		// MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		//PeliculaDAO peliculaDAO = Mockito.mock(PeliculaDAO.class);
		//PeliculaBS peliculaBS = new PeliculaBSImpl(peliculaDAO);
		
		// Cuando pedimos buscar todas las peliculas retorne Datos.PELICULAS
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}
	
	@Test
	void testFindPeliculaByNombreConActores() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		
		Assertions.assertEquals(2, pelicula.getActores().size());
	}
	
	@Test
	void testFindPeliculaByNombreConActoresVerify() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		
		// Con verify comprobamos que llamamos a determinados metodos del mock
		Mockito.verify(peliculaDAO).findAll();
		//Mockito.verify(peliculaDAO).crear(pelicula);
		Mockito.verify(actorDAO).findActoresByPelicula(2L);
		// Mockito.verify(actorDAO).findActoresByPelicula(5L);  No pasa la prueba
	}
	
	@Test
	void testCrearPelicula() {
		// BDD -> Desarrollo dirigido por comportamiento
		
		// 1.- Given (Preparacion)
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		//Mockito.any(Pelicula.class);  // crea una instancia falsa de pelicula
		//Mockito.anyList(); // crear una lista falsa
		//Mockito.when(peliculaDAO.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		
		Mockito.when(peliculaDAO.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		
		// 2.- When (Ejecucion)
		Pelicula pelicula = peliculaBS.crearNueva(peliculaNueva);
		
		// 3.- Then (Evaluar resultados)
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());		
	}
	
	@Test
	void testExcepciones() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenThrow(IllegalArgumentException.class);
		
		Exception ex = Assertions.assertThrows(IllegalArgumentException.class, () -> {
			peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		});
		
		// Comprobar que la excepcion es IllegalArgumentException
		Assertions.assertEquals(IllegalArgumentException.class, ex.getClass());
	}  
	
	@Test
	void testExcepcionesIdNull() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.isNull())).thenThrow(IllegalArgumentException.class);
		
		Exception ex = Assertions.assertThrows(IllegalArgumentException.class, () -> {
			peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		});
		
		// Comprobar que la excepcion es IllegalArgumentException
		Assertions.assertEquals(IllegalArgumentException.class, ex.getClass());
	}
	
	// Matchers: se utilizan para asegurar que determinados argumentos se pasan al Mock
	// se pueden utilizar desde la clase Mockito o desde ArgumentMatchers
	@Test
	void testArgumentMatchers() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		peliculaBS.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(peliculaDAO).findAll();
		Mockito.verify(actorDAO).findActoresByPelicula(ArgumentMatchers.argThat(arg -> arg != null & arg.equals(3L)));
		Mockito.verify(actorDAO).findActoresByPelicula(ArgumentMatchers.eq(3L));
	}
	
	// Crear un ArgumentMatcher personalizado
	public static class MiArgumentMatcher implements ArgumentMatcher<Long>{
		private Long argumento;

		@Override
		public boolean matches(Long argument) {
			argumento = argument;
			return argumento != null && argumento > 0;
		}
		
		@Override
		public String toString() {
			return "ERROR: " + argumento + " debe ser un numero positivo";
		}		
	}
	
	// Probar ArgumentMatcher personalizado
	@Test
	void testMiArgumentMatcher() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS_ID_NEGATIVO);
		//Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		peliculaBS.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(peliculaDAO).findAll();
		Mockito.verify(actorDAO).findActoresByPelicula(ArgumentMatchers.argThat(new MiArgumentMatcher()));
	}
	
	// Mockito nos ofrece la posibilidad de capturar los argumentos que pasamos al mock
	// Hay 2 formas de hacerlo: ArgumentCaptor o @Captor
	@Test
	void testCapturarArgumentos() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		peliculaBS.findPeliculaByNombreConActores("habitacion");
		
		// Crear una instancia de ArgumentCaptor 
		// Lo comento para problar la propiedad anotada con @Captor
		//ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		Mockito.verify(actorDAO).findActoresByPelicula(captor.capture());
		Assertions.assertEquals(3L, captor.getValue());
	}
	
	@Test
	void testCrearListaActores() {
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		// No podemos utilizar when cuando el metodo es de tipo void
		//Mockito.when(actorDAO.crearListaActores(null)).thenThrow(IllegalArgumentException.class);
		
		// La alternativa es doThrow
		Mockito.doThrow(IllegalArgumentException.class).when(actorDAO).crearListaActores(Mockito.anyList());
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			peliculaBS.crearNueva(peliculaNueva);
		});
	}
	
	@Test
	void testInvocarMetodoReal() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		
		// Llamar al metodo real
		Mockito.doCallRealMethod().when(actorDAO).findActoresByPelicula(Mockito.anyLong());
		
		// Llamar al mock
		//Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		
		System.out.println(pelicula);
		
		Assertions.assertEquals(2L, pelicula.getId());
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		Assertions.assertEquals(2, pelicula.getActores().size());
	}
	
	// Spy es un hibrido entre los mocks y los objetos reales
	// Spy no funciona desde interfaces o clases abstractas
	// debe ser una clase implementada
	@Test
	void testSpy() {
		// Crear los objetos spy
		PeliculaDAO peliculaDAO = Mockito.spy(PeliculaDAOImpl.class);  // siempre sobre la clase
		ActorDAO actorDAO = Mockito.spy(ActorDAOImpl.class);
		PeliculaBS peliculaBS = new PeliculaBSImpl(peliculaDAO, actorDAO);
		
		// Invocamos al objeto real solo que los ACTORES son de Datos
		// Si comento esta linea al no mockear el objeto me devuelte los Actores de actorDAOImpl
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Invocamos al objeto mock
		//Mockito.doReturn(Datos.ACTORES).when(actorDAO).findActoresByPelicula(Mockito.anyLong());
		
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombreConActores("El 47");
		
		System.out.println(pelicula);
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(2, pelicula.getActores().size());
	}
	
	// Probar el orden cuando utilizo mas de una peticion
	@Test
	void testOrdenInMocks() {
		Mockito.when(peliculaDAO.findAll()).thenReturn(Datos.PELICULAS);
		
		peliculaBS.findPeliculaByNombreConActores("Infiltrada");
		peliculaBS.findPeliculaByNombreConActores("47");
		
		InOrder order = Mockito.inOrder(peliculaDAO, actorDAO);
		order.verify(peliculaDAO).findAll();
		order.verify(actorDAO).findActoresByPelicula(2L);
		
		order.verify(peliculaDAO).findAll();
		order.verify(actorDAO).findActoresByPelicula(1L);
	}

}



















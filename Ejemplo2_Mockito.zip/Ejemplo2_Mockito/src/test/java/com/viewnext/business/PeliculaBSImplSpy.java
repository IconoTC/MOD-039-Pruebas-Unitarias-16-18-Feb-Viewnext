package com.viewnext.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.ActorDAO;
import com.viewnext.persistence.ActorDAOImpl;
import com.viewnext.persistence.PeliculaDAO;
import com.viewnext.persistence.PeliculaDAOImpl;
import com.viewnext.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculaBSImplSpy {
	
	@Spy
	PeliculaDAOImpl peliculaDAOImpl;
	
	@Spy
	ActorDAOImpl actorDAO;
	
	@InjectMocks
	PeliculaBSImpl peliculaBS;
	
	@Test
	void testSpy() {
		// Crear los objetos spy
		//PeliculaDAO peliculaDAO = Mockito.spy(PeliculaDAOImpl.class);  // siempre sobre la clase
		//ActorDAO actorDAO = Mockito.spy(ActorDAOImpl.class);
		//PeliculaBS peliculaBS = new PeliculaBSImpl(peliculaDAO, actorDAO);
		
		// Invocamos al objeto real solo que los ACTORES son de Datos
		// Si comento esta linea al no mockear el objeto me devuelte los Actores de actorDAOImpl
		Mockito.when(actorDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Invocamos al objeto mock
		//Mockito.doReturn(Datos.ACTORES).when(actorDAO).findActoresByPelicula(Mockito.anyLong());
		
		
		Pelicula pelicula = peliculaBS.findPeliculaByNombreConActores("El 47");
		
		System.out.println(pelicula);
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(2, pelicula.getActores().size());
	}

}
